import { useCallback, useEffect, useRef, useState } from 'react'
import { useMic } from './hooks/useMic.js'
import { usePushToTalk } from './hooks/usePushToTalk.js'
import { useSpeechRecognition } from './hooks/useSpeechRecognition.js'
import MicGate from './components/MicGate.jsx'
import MicPanel from './components/MicPanel.jsx'
import FieldSlots, {
  allFieldsFilled, nextEmptyField, orderCodesSubStep, FIELD_DEFS,
} from './components/FieldSlots.jsx'
import ResultModal from './components/ResultModal.jsx'
import HistoryTable from './components/HistoryTable.jsx'
import { parseForField, parseOrderCode } from './utils/parser.js'
import { parseVietnameseNumber } from './utils/vietnameseNumber.js'
import { lookupOrders, saveReceipt, listReceipts, validateReceipt } from './api.js'

const AUTO_LOOKUP_DELAY_MS = 1000

const emptyFields = () => ({
  receiptCode: null,
  date: null,
  orderCodes: [],
  receiptAmount: null,
})

const clearedValue = (fieldKey) => (fieldKey === 'orderCodes' ? [] : null)
const isEmptyValue = (v) => v === null || v === undefined || (Array.isArray(v) && v.length === 0)

export default function App() {
  const mic = useMic()
  const [fields, setFields] = useState(emptyFields())
  const [orderCodesConfirmed, setOrderCodesConfirmed] = useState(false)
  const [activeField, setActiveField] = useState(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [autoTriggerBlocked, setAutoTriggerBlocked] = useState(false)
  const [lookups, setLookups] = useState({})
  const [interim, setInterim] = useState('')
  const [rows, setRows] = useState([])
  const [busy, setBusy] = useState(false)
  const [validation, setValidation] = useState(null)

  const extras = { orderCodesConfirmed }
  const effectiveTarget = activeField || nextEmptyField(fields, extras)

  const fieldsRef = useRef(fields)
  const activeFieldRef = useRef(activeField)
  const orderConfirmedRef = useRef(orderCodesConfirmed)
  const targetForCurrentUtterance = useRef(null)
  useEffect(() => { fieldsRef.current = fields }, [fields])
  useEffect(() => { activeFieldRef.current = activeField }, [activeField])
  useEffect(() => { orderConfirmedRef.current = orderCodesConfirmed }, [orderCodesConfirmed])

  useEffect(() => { listReceipts().then(setRows).catch(() => { }) }, [])

  const onSpeechStart = useCallback(() => {
    const target = activeFieldRef.current || nextEmptyField(
      fieldsRef.current, { orderCodesConfirmed: orderConfirmedRef.current }
    )
    targetForCurrentUtterance.current = target
    setInterim('')
  }, [])

  const onFinal = useCallback((text) => {
    setInterim('')
    const target = targetForCurrentUtterance.current
    targetForCurrentUtterance.current = null
    if (!target) return

    if (target === 'orderCodes') {
      const list = fieldsRef.current.orderCodes || []
      const subStep = orderCodesSubStep(list)
      if (subStep === 'code') {
        const code = parseOrderCode(text)
        if (!code) return
        setFields((prev) => ({
          ...prev,
          orderCodes: [...(prev.orderCodes || []), { code, amount: null }],
        }))
      } else {
        const amount = parseVietnameseNumber(text)
        if (amount == null) return
        setFields((prev) => {
          const arr = [...(prev.orderCodes || [])]
          arr[arr.length - 1] = { ...arr[arr.length - 1], amount }
          return { ...prev, orderCodes: arr }
        })
      }
      return
    }

    const value = parseForField(text, target)
    if (isEmptyValue(value)) return
    setFields((prev) => ({ ...prev, [target]: value }))
    setActiveField(null)
  }, [])

  const speech = useSpeechRecognition({ onFinal, onInterim: setInterim, lang: 'vi-VN' })

  const { holding } = usePushToTalk({
    enabled: mic.status === 'ok' && !modalOpen,
    onStart: () => { onSpeechStart(); speech.start() },
    onStop: () => speech.stop(),
  })

  /**
   * Xóa 1 order theo index — dùng khi click badge trong FieldSlots.
   * Nếu xóa hết → tự reset orderCodesConfirmed để user có thể nói lại từ đầu.
   */
  const removeOrderCodeAt = useCallback((idx) => {
    setFields((prev) => {
      const arr = [...(prev.orderCodes || [])]
      arr.splice(idx, 1)
      return { ...prev, orderCodes: arr }
    })
    setOrderCodesConfirmed(false)
    setAutoTriggerBlocked(false)
    // Nếu đang đứng ở field khác, chuyển focus về orderCodes để user nói tiếp
    setActiveField('orderCodes')
  }, [])

  // ==================================================================
  // Ctrl → chốt orderCodes (bỏ đơn thiếu) và qua Tổng tiền
  // Shift → xóa đơn cuối cùng (dù đủ hay thiếu)
  // ==================================================================
  useEffect(() => {
    const ctrl = { active: false, combo: false }
    const shift = { active: false, combo: false }
    const isCtrl = (e) => e.code === 'ControlLeft' || e.code === 'ControlRight'
    const isShift = (e) => e.code === 'ShiftLeft' || e.code === 'ShiftRight'
    const isTyping = () => ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)

    const onDown = (e) => {
      // Ctrl tracking
      if (isCtrl(e)) {
        if (!ctrl.active) { ctrl.active = true; ctrl.combo = false }
      } else if (ctrl.active) {
        ctrl.combo = true
      }
      // Shift tracking (bỏ qua khi Ctrl đang được nhấn — tránh Ctrl+Shift)
      if (isShift(e)) {
        if (!shift.active && !ctrl.active) { shift.active = true; shift.combo = false }
      } else if (shift.active) {
        shift.combo = true
      }
    }

    const onUp = (e) => {
      if (isCtrl(e)) {
        const wasCombo = ctrl.combo
        ctrl.active = false
        ctrl.combo = false
        if (wasCombo || isTyping() || modalOpen || holding) return
        confirmOrderCodes()
      } else if (isShift(e)) {
        const wasCombo = shift.combo
        shift.active = false
        shift.combo = false
        if (wasCombo || isTyping() || modalOpen || holding) return
        removeLastOrderCode()
      }
    }

    const confirmOrderCodes = () => {
      const current = fieldsRef.current
      const confirmed = orderConfirmedRef.current
      const active = activeFieldRef.current
      const target = active || nextEmptyField(current, { orderCodesConfirmed: confirmed })
      if (target !== 'orderCodes') return
      if (!current.orderCodes || current.orderCodes.length === 0) return
      const kept = current.orderCodes.filter((o) => o.code && o.amount != null)
      setFields((prev) => ({ ...prev, orderCodes: kept }))
      setOrderCodesConfirmed(true)
      setActiveField(null)
    }

    const removeLastOrderCode = () => {
      const current = fieldsRef.current
      const confirmed = orderConfirmedRef.current
      const active = activeFieldRef.current
      const target = active || nextEmptyField(current, { orderCodesConfirmed: confirmed })
      if (target !== 'orderCodes') return
      if (!current.orderCodes || current.orderCodes.length === 0) return
      const arr = current.orderCodes.slice(0, -1)
      setFields((prev) => ({ ...prev, orderCodes: arr }))
    }

    window.addEventListener('keydown', onDown)
    window.addEventListener('keyup', onUp)
    return () => {
      window.removeEventListener('keydown', onDown)
      window.removeEventListener('keyup', onUp)
    }
  }, [modalOpen, holding])

  useEffect(() => {
    if (modalOpen || autoTriggerBlocked) return
    if (!allFieldsFilled(fields, extras)) return
    const t = setTimeout(async () => {
      const codes = (fields.orderCodes || []).map((o) => o.code).filter(Boolean)
      setBusy(true)
      try {
        const [lookupMap, valResult] = await Promise.all([
          codes.length ? lookupOrders(codes) : Promise.resolve({}),
          validateReceipt(fields.receiptCode, fields.date?.iso || null).catch(() => null),
        ])
        setLookups(lookupMap)
        setValidation(valResult)
      } catch (e) {
        console.error(e)
        setLookups({})
        setValidation(null)
      } finally {
        setBusy(false)
      }
      setModalOpen(true)
    }, AUTO_LOOKUP_DELAY_MS)
    return () => clearTimeout(t)
  }, [fields, orderCodesConfirmed, modalOpen, autoTriggerBlocked])

  useEffect(() => {
    if (!modalOpen) return
    const onKey = async (e) => {
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return
      if (e.code === 'Enter') { e.preventDefault(); await handleSave() }
      else if (e.code === 'Escape') { e.preventDefault(); closeModal() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line
  }, [modalOpen, fields, lookups])

  const handleSave = async () => {
    // Block save on duplicate
    if (validation?.status === 'duplicate') return

    const payload = {
      receiptCode: fields.receiptCode,
      receiptDate: fields.date?.iso || null,
      customerNameVoice: null,
      receiptAmount: fields.receiptAmount,
      orders: (fields.orderCodes || []).map((o) => {
        const l = lookups[o.code] || {}
        return {
          orderCode: o.code,
          invoiceCode: l.invoiceCode || 'N/A',
          customerName: l.customerName || null,
          orderAmount: o.amount ?? null,
        }
      }),
    }
    try {
      const saved = await saveReceipt(payload)
      // Only append to visible table if OK. Not_continuous: save silently.
      if (validation?.status !== 'not_continuous') {
        setRows((prev) => [saved, ...prev])
      }
      resetAll()
    } catch (e) {
      if (e.code === 'duplicate') {
        // Server rejected — refresh validation and keep modal open
        setValidation(e.payload)
        alert('Không thể lưu: ' + (e.payload?.message || e.message))
      } else {
        alert('Lỗi khi lưu: ' + e.message)
      }
    }
  }

  const closeModal = () => { setModalOpen(false); setAutoTriggerBlocked(true); setValidation(null) }

  const onFieldClick = (fieldKey) => {
    setModalOpen(false)
    setFields((prev) => ({ ...prev, [fieldKey]: clearedValue(fieldKey) }))
    setActiveField(fieldKey)
    setAutoTriggerBlocked(false)
    if (fieldKey === 'orderCodes') setOrderCodesConfirmed(false)
  }

  const resetAll = () => {
    setFields(emptyFields())
    setOrderCodesConfirmed(false)
    setLookups({})
    setActiveField(null)
    setValidation(null)
    setAutoTriggerBlocked(false)
    setModalOpen(false)
    setInterim('')
  }

  const anyFilled = FIELD_DEFS.some((f) => f.display(fields[f.key]) != null)

  const statusText = () => {
    if (holding) {
      if (effectiveTarget === 'orderCodes') {
        const sub = orderCodesSubStep(fields.orderCodes)
        return sub === 'code'
          ? `Đang nghe mã đơn #${fields.orderCodes.length + 1}...`
          : `Đang nghe số tiền cho ${fields.orderCodes[fields.orderCodes.length - 1]?.code}...`
      }
      return `Đang nghe: ${labelOf(effectiveTarget)}...`
    }
    if (!effectiveTarget) return 'Tất cả đã fill. Chờ 1s để xem kết quả.'
    if (effectiveTarget === 'orderCodes') {
      const sub = orderCodesSubStep(fields.orderCodes)
      const n = fields.orderCodes.length
      if (sub === 'code') return `Space: nói mã đơn #${n + 1}${n > 0 ? '  ·  Ctrl: xong  ·  Shift: xóa đơn cuối' : ''}`
      return `Space: nói số tiền cho ${fields.orderCodes[n - 1]?.code}  ·  Shift: xóa đơn cuối`
    }
    return `Space: nói ${labelOf(effectiveTarget)}`
  }

  return (
    <div className="h-dvh flex flex-col overflow-hidden bg-slate-50">
      <header className="shrink-0 bg-white border-b">
        <div className="px-6 py-2.5 flex items-center justify-between">
          <h1 className="text-lg font-semibold">Receipt Voice Entry</h1>
          <div className="text-xs text-slate-500">
            <kbd className="px-2 py-0.5 bg-slate-100 border rounded">Space</kbd> nói ·{' '}
            <kbd className="px-2 py-0.5 bg-slate-100 border rounded">Ctrl</kbd> xong mã đơn ·{' '}
            <kbd className="px-2 py-0.5 bg-slate-100 border rounded">Shift</kbd> xóa đơn cuối ·{' '}
            <kbd className="px-2 py-0.5 bg-slate-100 border rounded">Enter</kbd> lưu ·{' '}
            <kbd className="px-2 py-0.5 bg-slate-100 border rounded">Esc</kbd> đóng
          </div>
        </div>
      </header>

      <main className="flex-1 min-h-0 overflow-hidden">
        <MicGate mic={mic}>
          <div className="h-full grid grid-cols-[30%_1fr] gap-4 p-4 overflow-hidden">
            <div className="min-w-0 min-h-0 overflow-y-auto space-y-3 pr-1">
              <MicPanel mic={mic} />

              {!speech.supported && (
                <div className="p-3 bg-amber-50 border border-amber-300 text-amber-800 rounded text-sm">
                  Trình duyệt không hỗ trợ Web Speech API. Vui lòng dùng Chrome.
                </div>
              )}

              <div className={`p-2.5 rounded-lg border-2 transition-all ${holding ? 'border-red-500 bg-red-50' : 'border-slate-200 bg-white'
                }`}>
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${holding ? 'bg-red-500 animate-pulse' : 'bg-slate-300'
                    }`} />
                  <span className="text-xs text-slate-700 truncate flex-1">{statusText()}</span>
                  {busy && <span className="text-xs text-slate-500">Tra cứu...</span>}
                  {anyFilled && !modalOpen && (
                    <button
                      onClick={resetAll}
                      className="text-xs text-slate-500 hover:text-red-600 underline shrink-0"
                    >
                      Xoá
                    </button>
                  )}
                </div>
                <div className="mt-1 text-xs text-slate-500 italic min-h-[16px] truncate">
                  {interim ? `"${interim}"` : ''}
                </div>
              </div>

              <FieldSlots
                fields={fields}
                effectiveTarget={effectiveTarget}
                holding={holding}
                onFieldClick={onFieldClick}
                orderCodesConfirmed={orderCodesConfirmed}
                onRemoveOrderCode={removeOrderCodeAt}
              />

              <details className="text-xs text-slate-600 bg-white p-2 rounded border">
                <summary className="cursor-pointer font-medium">Hướng dẫn</summary>
                <div className="mt-1.5 space-y-1">
                  <div>• Giữ <kbd className="px-1 bg-slate-100 border rounded">Space</kbd> nói, thả để parse.</div>
                  <div>• Ô <b>Mã đơn & số tiền</b>: xen kẽ mã → tiền → mã → tiền → ...</div>
                  <div className="pl-4">VD: Space "10135" → Space "ba triệu sáu" → Space "3016" → Space "1 6 2 3 5 0 1"</div>
                  <div>• Nhấn <kbd className="px-1 bg-slate-100 border rounded">Ctrl</kbd> để chốt (bỏ đơn thiếu tiền) và qua Tổng tiền.</div>
                  <div>• Nhấn <kbd className="px-1 bg-slate-100 border rounded">Shift</kbd> để xóa đơn cuối cùng (dù đủ hay thiếu).</div>
                  <div>• Click vào từng badge đơn để xóa đơn đó (hover sẽ chuyển đỏ).</div>
                  <div>• Prefix chữ: "nờ gờ 03567" → NG-03567.</div>
                  <div>• Click ô field để nói lại (xoá ô đó).</div>
                </div>
              </details>
            </div>

            <div className="min-w-0 min-h-0 flex flex-col overflow-hidden">
              <div className="text-sm font-semibold mb-2 shrink-0">Lịch sử phiếu thu</div>
              <div className="flex-1 min-h-0">
                <HistoryTable rows={rows} />
              </div>
            </div>
          </div>
        </MicGate>
      </main>

      {modalOpen && (
        <ResultModal fields={fields} lookups={lookups} validation={validation} onSave={handleSave} onClose={closeModal} />
      )}
    </div>
  )
}

const labelOf = (key) => FIELD_DEFS.find((f) => f.key === key)?.label || ''