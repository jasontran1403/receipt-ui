import { useMemo, useState } from 'react'
import { formatMoney } from '../utils/formatMoney.js'

function matches(row, q) {
  if (!q) return true
  const s = q.toLowerCase()
  if ((row.receiptCode || '').toLowerCase().includes(s)) return true
  for (const o of row.orders || []) {
    if ((o.orderCode || '').toLowerCase().includes(s)) return true
    if ((o.invoiceCode || '').toLowerCase().includes(s)) return true
    if ((o.customerName || '').toLowerCase().includes(s)) return true
  }
  return false
}

function flatten(rows) {
  const out = []
  for (const r of rows) {
    const orders = r.orders && r.orders.length ? r.orders : [null]
    orders.forEach((o, idx) => {
      out.push({
        rowKey: `${r.id}-${o?.id ?? 'empty'}-${idx}`,
        isFirstOfReceipt: idx === 0,
        receipt: r,
        order: o,
      })
    })
  }
  return out
}

export default function HistoryTable({ rows }) {
  const [q, setQ] = useState('')
  const filteredReceipts = useMemo(() => rows.filter((r) => matches(r, q.trim())), [rows, q])
  const flatRows = useMemo(() => flatten(filteredReceipts), [filteredReceipts])

  return (
    <div className="flex flex-col h-full bg-white border rounded-lg shadow-sm overflow-hidden">
      <div className="shrink-0 p-3 border-b bg-white">
        <div className="relative">
          <input
            type="text"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Tìm theo mã phiếu thu / mã đơn / mã invoice / tên khách..."
            className="w-full pl-8 pr-8 py-2 text-sm border rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-400"
          />
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
          {q && (
            <button
              onClick={() => setQ('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-sm"
            >✕</button>
          )}
        </div>
        <div className="text-xs text-slate-500 mt-1">
          {filteredReceipts.length} / {rows.length} phiếu thu · {flatRows.length} dòng đơn hàng
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-slate-700 sticky top-0 z-10">
            <tr>
              <th className="text-left px-3 py-2">Phiếu thu</th>
              <th className="text-left px-3 py-2">Ngày</th>
              <th className="text-left px-3 py-2">Mã đơn</th>
              <th className="text-left px-3 py-2">Tên khách</th>
              <th className="text-left px-3 py-2">Mã invoice</th>
              <th className="text-right px-3 py-2">Số tiền</th>
              <th className="text-right px-3 py-2">Tổng tiền</th>
            </tr>
          </thead>
          <tbody>
            {flatRows.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center text-slate-400 py-10">
                  {rows.length === 0 ? 'Chưa có phiếu thu nào.' : 'Không tìm thấy phiếu phù hợp.'}
                </td>
              </tr>
            ) : (
              flatRows.map(({ rowKey, isFirstOfReceipt, receipt, order }) => (
                <tr
                  key={rowKey}
                  className={`border-t ${isFirstOfReceipt ? 'border-slate-300' : 'border-slate-100'} hover:bg-slate-50`}
                >
                  <td className={`px-3 py-2 font-mono ${isFirstOfReceipt ? 'font-semibold' : 'text-slate-300'}`}>
                    {isFirstOfReceipt ? receipt.receiptCode : ''}
                  </td>
                  <td className={`px-3 py-2 ${isFirstOfReceipt ? '' : 'text-slate-300'}`}>
                    {isFirstOfReceipt ? (receipt.receiptDate || '—') : ''}
                  </td>
                  <td className="px-3 py-2 font-mono">{order?.orderCode || '—'}</td>
                  <td className="px-3 py-2 truncate max-w-[200px]">{order?.customerName || '—'}</td>
                  <td className="px-3 py-2 font-mono">{order?.invoiceCode || '—'}</td>
                  <td className="px-3 py-2 text-right font-mono">
                    {order?.orderAmount != null ? formatMoney(order.orderAmount) : '—'}
                  </td>
                  <td className={`px-3 py-2 text-right font-mono ${isFirstOfReceipt ? 'font-semibold' : 'text-slate-300'}`}>
                    {isFirstOfReceipt ? formatMoney(receipt.receiptAmount) : ''}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}