import { formatMoney } from '../utils/formatMoney.js'

const pad = (n) => String(n).padStart(2, '0')

export const FIELD_DEFS = [
  {
    key: 'receiptCode',
    label: 'Số phiếu thu',
    example: 'VD: "một ba bảy bảy chín"',
    display: (v) => v || null,
  },
  {
    key: 'date',
    label: 'Ngày',
    example: 'VD: "hai chín bốn hai sáu" (DDMYY)',
    display: (v) => (v ? `${pad(v.day)}/${pad(v.month)}/${v.year}` : null),
  },
  {
    key: 'orderCodes',
    label: 'Mã đơn & số tiền',
    example: 'Space: mã đơn · Space: số tiền · … · Ctrl: xong',
    // Chỉ dùng để check "có content chưa" (hasContent) — UI thật render riêng bên dưới.
    display: (v) => {
      if (!v || !v.length) return null
      return v.map((o) =>
        o.amount == null ? `${o.code} ⏳` : `${o.code}: ${formatMoney(o.amount)}`
      ).join(' · ')
    },
  },
  {
    key: 'receiptAmount',
    label: 'Tổng tiền',
    example: 'VD: "ba triệu sáu" hoặc "tám mươi triệu"',
    display: (v) => (v != null ? formatMoney(v) : null),
  },
]

export function isFieldFilled(fieldKey, value, extras = {}) {
  if (fieldKey === 'orderCodes') {
    if (!extras.orderCodesConfirmed) return false
    return Array.isArray(value) && value.length > 0 &&
      value.every((o) => o.code && o.amount != null)
  }
  const def = FIELD_DEFS.find((f) => f.key === fieldKey)
  return def?.display(value) != null
}

export function allFieldsFilled(fields, extras = {}) {
  return FIELD_DEFS.every((f) => isFieldFilled(f.key, fields[f.key], extras))
}

export function nextEmptyField(fields, extras = {}) {
  const f = FIELD_DEFS.find((d) => !isFieldFilled(d.key, fields[d.key], extras))
  return f ? f.key : null
}

/** Sub-step within orderCodes: 'code' (đợi nói mã đơn) or 'amount' (đợi nói số tiền). */
export function orderCodesSubStep(orderCodes) {
  if (!orderCodes || orderCodes.length === 0) return 'code'
  const last = orderCodes[orderCodes.length - 1]
  return last.amount == null ? 'amount' : 'code'
}

export default function FieldSlots({
  fields,
  effectiveTarget,
  holding,
  onFieldClick,
  orderCodesConfirmed,
  onRemoveOrderCode,
}) {
  const subStep = orderCodesSubStep(fields.orderCodes)
  const pairCount = (fields.orderCodes || []).length

  return (
    <div className="space-y-2">
      {FIELD_DEFS.map((f) => {
        const v = fields[f.key]
        const hasContent = f.display(v) != null
        const isTarget = effectiveTarget === f.key
        const listening = isTarget && holding

        const showGreen = f.key === 'orderCodes'
          ? orderCodesConfirmed && hasContent
          : hasContent

        let cls = 'w-full text-left p-3 rounded-lg border-2 transition-all focus:outline-none '
        if (listening)      cls += 'border-red-500 bg-red-50 ring-4 ring-red-200 animate-pulse'
        else if (isTarget)  cls += 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
        else if (showGreen) cls += 'border-green-400 bg-white hover:border-green-600'
        else if (hasContent) cls += 'border-slate-400 bg-white hover:border-slate-600'
        else                cls += 'border-slate-300 border-dashed bg-white hover:border-slate-500'

        let subLabel = null
        if (isTarget && f.key === 'orderCodes' && !orderCodesConfirmed) {
          const nextIdx = subStep === 'code' ? pairCount + 1 : pairCount
          const codeOfLast = subStep === 'amount' ? fields.orderCodes[pairCount - 1]?.code : null
          if (holding) {
            subLabel = subStep === 'code'
              ? `● đang nghe mã đơn #${nextIdx}`
              : `● đang nghe số tiền cho ${codeOfLast}`
          } else {
            subLabel = subStep === 'code'
              ? `→ nói mã đơn #${nextIdx}`
              : `→ nói số tiền cho ${codeOfLast}`
          }
        } else if (isTarget) {
          subLabel = holding ? '● đang nghe' : '→ tiếp theo'
        }

        return (
          <button key={f.key} onClick={() => onFieldClick(f.key)} className={cls} type="button">
            <div className="flex items-center justify-between mb-1 gap-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                {f.label}
              </span>
              {subLabel && (
                <span className="text-xs text-blue-600 font-medium truncate">{subLabel}</span>
              )}
            </div>

            {hasContent ? (
              f.key === 'orderCodes' ? (
                <div className="space-y-1.5 mt-1">
                  {v.map((o, idx) => {
                    const isIncomplete = o.amount == null
                    return (
                      <div
                        key={idx}
                        role="button"
                        tabIndex={-1}
                        onClick={(e) => {
                          e.stopPropagation()
                          onRemoveOrderCode?.(idx)
                        }}
                        title="Click để xóa đơn này"
                        className="flex items-center justify-between px-3 py-1.5 rounded-md
                                   border-2 border-black bg-white text-slate-900
                                   font-mono text-sm cursor-pointer select-none
                                   hover:border-red-500 hover:text-red-600
                                   transition-colors"
                      >
                        <span className="truncate">
                          {o.code}
                          {isIncomplete ? ' - ⏳' : ` - ${formatMoney(o.amount)}`}
                        </span>
                        <span className="ml-2 shrink-0 text-slate-400 group-hover:text-red-500 text-xs">
                          ✕
                        </span>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div className="text-sm font-mono font-semibold text-slate-900 break-words">
                  {f.display(v)}
                </div>
              )
            ) : (
              <div className="text-xs text-slate-400 italic break-words">{f.example}</div>
            )}

            {f.key === 'orderCodes' && isTarget && !orderCodesConfirmed && (
              <div className="mt-1.5 text-[11px] text-slate-500 space-y-0.5">
                {pairCount > 0 && (
                  <div>
                    Nhấn <kbd className="px-1 bg-slate-100 border rounded">Ctrl</kbd> để chốt và qua Tổng tiền
                  </div>
                )}
                <div>
                  Nhấn <kbd className="px-1 bg-slate-100 border rounded">Shift</kbd> để xóa đơn cuối
                  {' · '}
                  hoặc click vào từng đơn để xóa
                </div>
              </div>
            )}
          </button>
        )
      })}
    </div>
  )
}